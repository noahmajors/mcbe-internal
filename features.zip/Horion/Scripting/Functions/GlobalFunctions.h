#pragma once

#include "../ScriptManager.h"
#include "Vector3Functions.h"

class GlobalFunctions {
public:
	DECL_FUN(log);
};
